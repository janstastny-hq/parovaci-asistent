#!/usr/bin/env python3
"""Sestaví proto-data.json ze zdrojových .txt souborů.

Použití:
    python3 scripts/generate-proto-data.py [cesta_ke_zdrojum] [vystup.json]

Očekává v dané složce: kategorie.txt, pravidla.txt, parametry.txt, parametry-v2.txt
(výchozí složka = aktuální adresář, výchozí výstup = proto-data.json).
"""
import json
import os
import re
import sys

SRC = sys.argv[1] if len(sys.argv) > 1 else "."
OUT = sys.argv[2] if len(sys.argv) > 2 else "proto-data.json"


def load_categories(path):
    with open(path, encoding="utf-8", errors="ignore") as f:
        obsah = f.read()
    found = re.findall(r"<CATEGORY_FULLNAME>(.*?)</CATEGORY_FULLNAME>", obsah, re.DOTALL)
    return sorted({c.strip() for c in found if c.strip()})


def parse_db(path):
    """Klíč je vždy první → bereme NEJLEVĚJŠÍ spaced oddělovač.

    Tím se 'pravidla.txt' správně rozdělí na ' – ' (en-dash) a hodnota si
    ponechá vnitřní ' - ' (pomlčku) i koncové ' – ' před příkladem.
    (Oprava chyby původního parseru, který dělil na prvním ' - '.)
    """
    db = {}
    seps = [" – ", " - ", " — ", " = "]
    if not os.path.exists(path):
        return db
    with open(path, encoding="utf-8", errors="ignore") as f:
        for line in f:
            s = line.strip()
            if not s:
                continue
            best, bestpos = None, None
            for sep in seps:
                i = s.find(sep)
                if i != -1 and (bestpos is None or i < bestpos):
                    bestpos, best = i, sep
            if best is None:
                continue
            k, v = s.split(best, 1)
            db[k.strip().lower()] = v.strip()
    return db


def main():
    data = {
        "categories": load_categories(os.path.join(SRC, "kategorie.txt")),
        "rules": parse_db(os.path.join(SRC, "pravidla.txt")),
        "params": parse_db(os.path.join(SRC, "parametry.txt")),
        "paramsV2": parse_db(os.path.join(SRC, "parametry-v2.txt")),
    }
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False)
    print(
        f"OK → {OUT}  |  kategorie: {len(data['categories'])}, "
        f"pravidla: {len(data['rules'])}, povinné: {len(data['params'])}, "
        f"V2: {len(data['paramsV2'])}"
    )


if __name__ == "__main__":
    main()
